﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;

/*
using ICSharpCode.AvalonEdit;
using ICSharpCode.AvalonEdit.Document;
using ICSharpCode.AvalonEdit.Highlighting;
*/

namespace ICSharpCode.HtmlSyntaxColorizer
{
    public class HtmlWriter
    {
        public string GenerateHtml(string code, string highlighterName)
        {
            /*
            TextDocument doc = new TextDocument(code);
            IHighlightingDefinition def = HighlightingManager.Instance.GetDefinition("C#");
            DocumentHighlighter highlighter = new DocumentHighlighter(doc, def.MainRuleSet);
            string html = HtmlClipboard.CreateHtmlFragment(doc, highlighter, null, new HtmlOptions());
            */

            return "";
        }
    }
}
