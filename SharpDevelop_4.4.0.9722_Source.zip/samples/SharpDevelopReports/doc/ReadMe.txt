The Getting Started Guide is located here:

http://sharpdevelopreports.net/FeatureTour.ashx